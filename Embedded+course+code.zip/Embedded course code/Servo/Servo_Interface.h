/*
 * Servo_Interface.h
 *
 *  Created on: Jul 18, 2022
 *      Author: hazemahmed
 */

#ifndef SERVO_INTERFACE_H_
#define SERVO_INTERFACE_H_

#define TCCR1A *((volatile u8*)0x4F)
#define TCCR1B *((volatile u8*)0x4E)
#define ICR1 *((volatile u16*)0x46)
#define OCR1 *((volatile u16*)0x4A)

void Timer1_init();
void SET_TOP_Value(u16 Top_value);
void SET_OCR_Value(u16 OCR_value);
#endif /* SERVO_INTERFACE_H_ */
