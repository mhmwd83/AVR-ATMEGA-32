/*
 * main.c
 *
 *  Created on: Jul 6, 2022
 *      Author: hazemahmed
 */


#include"BIT_OP.h"
#include"STD_TYPES.h"
#include"GIE_Interface.h"
#include"Timer_Interface.h"
#include"DIO_Interface.h"

#define F_CPU 8000000UL
//Normal mode
int main(){
	SET_Direction(PORT_B, PIN_3, OUTPUT);
	while(1){

	}
	return 0;
}
void __vector_11(void) __attribute__((signal));
void __vector_11(void){
	static u8 flag=0;
	static u8 count=0;
	if(count==245){
		if(flag==0){
			SET_Value(PORT_B, PIN_3, HIGH);
			flag=1;
		}
		else if(flag==1){
			SET_Value(PORT_B, PIN_3, LOW);
						flag=0;
		}
		count=0;
		Timer_Set_Preload(220);
	}
	else{
		count++;
	}
}
// PWM
/*int main(){
	SET_Direction(PORT_B, PIN_3, OUTPUT);
	SET_Direction(PORT_A, PIN_6, OUTPUT);
	SET_Direction(PORT_A, PIN_7, OUTPUT);
	SET_Value(PORT_A, PIN_6, HIGH);
	SET_Value(PORT_A, PIN_7, LOW);
	Timer_Init();
	while(1){
		Timer_Set_CTC(50);
	}
	return 0;
}*/
