/*
 * main.c
 *
 *  Created on: Jul 18, 2022
 *      Author: hazemahmed
 */

#include"BIT_OP.h"
#include"STD_TYPES.h"
#include"USART_Interface.h"
#include"DIO_Interface.h"
int main(){
	SET_Direction(PORT_B, PIN_0, INPUT);
	SET_Value(PORT_B, PIN_0, HIGH);
	SET_Direction(PORT_D, PIN_0, INPUT);
	SET_Direction(PORT_D, PIN_1, OUTPUT);
	USART_init();
	while(1){
		if(!GET_Value(PORT_B, PIN_0)){
			USART_Send('1');
		}
		else if(GET_Value(PORT_B, PIN_0)){
			USART_Send('0');
		}
	}
	return 0;
}
