/*
 * main.c
 *
 *  Created on: Jul 5, 2022
 *      Author: hazemahmed
 */

#include"BIT_OP.h"
#include"STD_TYPES.h"
#include"DIO_Interface.h"
#include"LCD_Interface.h"

int main(){
	SET_Direction(PORT_C, PIN_0, OUTPUT);
	SET_Direction(PORT_C, PIN_1, OUTPUT);
	SET_Direction(PORT_C, PIN_2, OUTPUT);
	SET_Direction_4MSB(PORT_C, OUTPUT);
	LCD_Init();
	LCD_String("Hazem");
	LCD_SendNumbers(1998);
	while(1){

	}
	return 0;
}
