/*
 * Keypad_Interface.h
 *
 *  Created on: Jul 5, 2022
 *      Author: hazemahmed
 */

#ifndef KEYPAD_INTERFACE_H_
#define KEYPAD_INTERFACE_H_

u8 Keypad_GetKey();

#endif /* KEYPAD_INTERFACE_H_ */
