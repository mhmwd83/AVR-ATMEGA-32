/*
 * main.c
 *
 *  Created on: Jul 19, 2022
 *      Author: hazemahmed
 */



#include"BIT_OP.h"
#include"STD_TYPES.h"
#include"TWI_Interface.h"
#include"DIO_Interface.h"
#include<util/delay.h>
int main(){
	SET_Direction(PORT_B, PIN_0, INPUT);
	SET_Value(PORT_B, PIN_0, HIGH);
	TWI_MASTER_INIT(0);
	TWI_SEND_START_CONDITION();
	TWI_SEND_SLAVE_ADDRESS_WITH_WRITE(0x20);
	while(1){
		if((GET_Value(PORT_B, PIN_0))==LOW){
			TWI_MASTER_SEND_DATA(1);
		}
		else if((GET_Value(PORT_B, PIN_0))==HIGH){
			TWI_MASTER_SEND_DATA(0);
		}
		_delay_ms(200);
		TWI_SEND_REPEATED_START_CONDITION();
		TWI_SEND_SLAVE_ADDRESS_WITH_WRITE(0x20);
	}
	return 0;
}
